To generate the sample cloudbase-init.conf file, run the following command from the top
level of the cloudbase-init directory:

    oslo-config-generator --config-file etc/cloudbase-init/cloudbase-init-config-generator.conf
