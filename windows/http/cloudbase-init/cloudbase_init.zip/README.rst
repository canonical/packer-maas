Portable Multi-Cloud Initialization Service
===========================================

* Author:         Cloudbase Solutions Srl
* Contact:        info@cloudbasesolutions.com
* Home page:      http://www.cloudbase.it/cloud-init-windows/

* Documentation:  http://cloudbase-init.readthedocs.org/en/latest/
* Source:         https://github.com/openstack/cloudbase-init
* License:        Apache 2.0


Downloads
---------

Stable
~~~~~~

* (64bit) https://www.cloudbase.it/downloads/CloudbaseInitSetup_Stable_x64.msi
* (32bit) https://www.cloudbase.it/downloads/CloudbaseInitSetup_Stable_x86.msi

Beta
~~~~

* (64bit) https://www.cloudbase.it/downloads/CloudbaseInitSetup_x64.msi
* (32bit) https://www.cloudbase.it/downloads/CloudbaseInitSetup_x86.msi


Got a question?
---------------

Visit http://ask.cloudbase.it/questions/
