.. cloudbase-init documentation master file, created by
   sphinx-quickstart on Wed Jun 03 01:25:56 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to cloudbase-init's documentation!
==========================================

Contents:

.. toctree::
   :maxdepth: 2

   intro
   tutorial
   services
   plugins
   userdata


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
